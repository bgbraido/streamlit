import streamlit as st

st.session_state["df_spotify"]